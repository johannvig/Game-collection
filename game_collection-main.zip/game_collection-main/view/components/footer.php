<link rel="stylesheet" href="assets/style/footer.css">
<footer>
    Game Collection - 2023 - Tous droits réservés
</footer>
