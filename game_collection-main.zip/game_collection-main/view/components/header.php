<link rel="stylesheet" href="assets/style/header.css">
<header>
    <div class="logo">Logo</div>
    <div class="acces">
        <a href="home">MA BIBLIOTHÈQUE</a>
        <a href="games">AJOUTER UN JEU</a>
        <a href="ranking">CLASSEMENT</a>
        <a href="profil">PROFIL</a>
    </div>
</header>
